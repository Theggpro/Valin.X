#######################################
#                                     #
#   by The_ggpro  -  Copyright 2025   #
# https://github.com/Theggpro/Valin.X #
#                                     #
#######################################




red = "\033[91m"
white = "\033[97m"
yellow = "\033[93m"
green = "\033[92m"
gray = "\033[90m"
cyan = "\033[96m"
reset = "\033[0m"

try:
    import webbrowser
    import re
    import pyzipper
    from tkinter import messagebox
    import subprocess
    import os
    import time
except Exception as e:
    print(f"Module Error: {e}")

def resize_console():
    if os.name == "nt":
        os.system("mode con: cols=85 lines=30")

resize_console()

option_01 = "Task Cleaner"
option_02 = "App Uninstaller"
option_03 = "App Installer"
option_04 = "Temp File Cleaner"
option_05 = "IP Refresh"
option_06 = "Antivirus Scan"
option_07 = "Soon"
option_08 = "Soon"
option_09 = "Soon"
option_10 = "Soon"

logo_ascii = r"""
           ___      ___ ________  ___       ___  ________          ___    ___ 
          |\  \    /  /|\   __  \|\  \     |\  \|\   ___  \       |\  \  /  /|
          \ \  \  /  / | \  \|\  \ \  \    \ \  \ \  \\ \  \      \ \  \/  / /
           \ \  \/  / / \ \   __  \ \  \    \ \  \ \  \\ \  \      \ \    / / 
            \ \    / /   \ \  \ \  \ \  \____\ \  \ \  \\ \  \ ___  /     \/  
             \ \__/ /     \ \__\ \__\ \_______\ \__\ \__\\ \__\\__ /  /\   \  
              \|__|/       \|__|\|__|\|_______|\|__|\|__| \|__\|__/__/ /\ __\ 
                                                                  |__|/ \|__|   
"""

option_info_txt = "V1.2"
option_next_txt = "Next Soon"
option_site_txt = "https://github.com/Theggpro/Valin.X"

def format_option(index, text):
    return f"{red}[{white}{index:02d}{red}]{white} {text.ljust(30)[:30].replace('-', ' ')}{reset}"

options_txt = [format_option(i + 1, text) for i, text in enumerate([
    option_01, option_02, option_03, option_04, option_05,
    option_06, option_07, option_08, option_09, option_10
])]

def display_menu():
    print(f"""
{logo_ascii}
 ┌─ {option_info_txt:<100}
 ├─ {option_site_txt:<114}
 └─┬──────────────────────────────────────────────────────────────────────────────────────┐
   │ Local Device                                                                         │
   └──────────────────────────────────────────────────────────────────────────────────────┘
   {options_txt[0]}
   {options_txt[1]}
   {options_txt[2]}
   {options_txt[3]}
   {options_txt[4]}
   {options_txt[5]}
   {options_txt[6]}
   {options_txt[7]}
   {options_txt[8]}
   {options_txt[9]}
 ──────────────────────────────────────────────────────────────────────────────────────────
""")

def loading_bar(task_name):
    print(f"{red}[INFO]{reset} Processing {task_name}:", end=" ")
    for i in range(35):
        print("█", end="", flush=True)
        time.sleep(0.05)
    print(f" {red}[DONE]{reset}")

def kill_task(task_name):
    try:
        subprocess.run(['taskkill', '/f', '/im', task_name], capture_output=True, text=True)
        print(f"{red}[KILL]{reset} {task_name} has been terminated.")
    except Exception as e:
        print(f"{red}[ERROR]{reset} Could not terminate {task_name}: {e}")

def uninstall_app(app_name):
    try:
        print(f"{red}[INFO]{reset} Uninstalling: {app_name}")
        command = f'powershell "Get-WmiObject -Query \\"SELECT * FROM Win32_Product WHERE Name = \'{app_name}\'\\" | ForEach-Object {{$_.Uninstall()}}"'
        subprocess.run(command, shell=True)
        print(f"{red}[FINISH]{reset} {app_name} has been uninstalled.")
    except Exception as e:
        print(f"{red}[ERROR]{reset} Could not uninstall {app_name}: {e}")

def install_app(app_name):
    try:
        print(f"{red}[INFO]{reset} Installing: {app_name}")
        os.system(f"winget install --silent --accept-source-agreements --accept-package-agreements \"{app_name}\"")
        print(f"{red}[FINISH]{reset} {app_name} has been installed.")
    except Exception as e:
        print(f"{red}[ERROR]{reset} Could not install {app_name}: {e}")

def clean_temp_files():
    try:
        print(f"{red}[INFO]{reset} Cleaning temporary files...")
        loading_bar("Temp Cleaner")
        os.system("del /q/f/s %TEMP%\\*")
        os.system("del /s /f /q C:\\Windows\\Temp\\*")
        print(f"{red}[FINISH]{reset} Temporary files cleaned.")
    except Exception as e:
        print(f"{red}[ERROR]{reset} Failed to clean temp files: {e}")

def refresh_ip():
    try:
        print(f"{red}[INFO]{reset} Releasing current IP...")
        loading_bar("Releasing IP")
        release_result = subprocess.run("ipconfig /release", capture_output=True, text=True)

        print(f"{red}[INFO]{reset} Renewing IP address...")
        loading_bar("Renewing IP")
        renew_result = subprocess.run("ipconfig /renew", capture_output=True, text=True)

        full_output = renew_result.stdout

        print(f"{red}[INFO]{reset} Analyzing IP configuration...\n")

        interfaces = re.split(r"\n\n+", full_output)
        for block in interfaces:
            if "Média déconnecté" in block:
                match = re.search(r"Carte .*?:", block)
                if match:
                    name = match.group().strip()
                    print(f"{red}[DISCONNECTED]{reset} {name}")
            elif "IPv4" in block or "IPv6" in block:
                name_match = re.search(r"Carte .*?:", block)
                name = name_match.group().strip() if name_match else "Interface inconnue"
                print(f"{green}[CONNECTED]{reset} {name}")
                for line in block.splitlines():
                    if "Adresse IPv4" in line:
                        print(f"   {cyan}IPv4 Address      :{reset} {line.split(':')[-1].strip()}")
                    elif "Adresse IPv6" in line and "liaison locale" not in line:
                        print(f"   {cyan}IPv6 Address      :{reset} {line.split(':')[-1].strip()}")
                    elif "liaison locale" in line:
                        print(f"   {cyan}IPv6 Local Link   :{reset} {line.split(':')[-1].strip()}")
                    elif "Passerelle" in line:
                        print(f"   {cyan}Gateway           :{reset} {line.split(':')[-1].strip()}")

        print(f"\n{red}[FINISH]{reset} IP address refreshed.\n")

    except Exception as e:
        print(f"{red}[ERROR]{reset} Failed to refresh IP: {e}")

    except Exception as e:
        print(f"{red}[ERROR]{reset} Failed to refresh IP: {e}")

def antivirus_scan_q():
    try:
        print(f"{red}[INFO]{reset} Starting quick antivirus scan...")
        exit_code = os.system("powershell -Command \"Start-MpScan -ScanType QuickScan\"")
        if exit_code == 0:
            print(f"{red}[FINISH]{reset} Quick scan complete.")
        else:
            print(f"{red}[ERROR]{reset} Quick scan failed with exit code {exit_code}.")
    except Exception as e:
        print(f"{red}[ERROR]{reset} Antivirus scan failed: {e}")

def antivirus_scan_f():
    try:
        print(f"{red}[INFO]{reset} Starting full antivirus scan...")
        exit_code = os.system("powershell -Command \"Start-MpScan -ScanType FullScan\"")
        if exit_code == 0:
            print(f"{red}[FINISH]{reset} Full scan complete.")
        else:
            print(f"{red}[ERROR]{reset} Full scan failed with exit code {exit_code}.")
    except Exception as e:
        print(f"{red}[ERROR]{reset} Antivirus scan failed: {e}")

task_list = ["explorer.exe","MsMpeng.exe","OneDrive.exe","Teams.exe","SearchUI.exe","GameBar.exe","XblAuthManager.exe","XblGameSave.exe","YourPhone.exe","AcroTray.exe","AGCInvokerUtility.exe","CCleanerUpdate.exe","SkypeApp.exe","SpotifyWebHelper.exe","NVIDIA Share.exe","nvcontainer.exe","nvsphelper64.exe","Razer Synapse Service.exe","Razer Central.exe","RzSDKServer.exe","SteelSeriesEngine.exe","LCore.exe","LogiOptions.exe","EpicGamesLauncher.exe","Steam.exe","steamwebhelper.exe","Origin.exe","UbisoftConnect.exe","GalaxyClient.exe","Twitch.exe","Overwolf.exe","Battle.net.exe","googledrivesync.exe","GoogleCrashHandler.exe","GoogleUpdate.exe","Dropbox.exe","BoxSync.exe","MEGAsync.exe","IntelGraphicsCommandCenter.exe","DSAService.exe","SurSvc.exe","Widgets.exe","SearchIndexer.exe","WerFault.exe","HPSmart.exe","HPSupportSolutionsFrameworkService.exe","SupportAssistAgent.exe","AWCC.exe","AppleMobileDeviceService.exe","iTunesHelper.exe","mDNSResponder.exe","jusched.exe","SamsungMagician.exe","SSStatus.exe","LenovoVantageService.exe","HotkeyService.exe","ArmouryCrate.UserSessionHelper.exe","DragonCenter.exe","MSICenter.exe","NahimicService.exe","RtkAudioService64.exe","NahimicSvc64.exe","KillerNetworkService.exe","AvastUI.exe","AVGUI.exe","Avira.ServiceHost.exe","McUICnt.exe","NortonSecurity.exe","bdagent.exe","avp.exe","McTray.exe","smartscreen.exe","flux.exe","displaycal.exe","TeamViewer.exe","AnyDesk.exe","remoting_host.exe","Zoom.exe","msedge.exe","brave.exe","opera_assistant.exe","maintenanceservice.exe","Discord.exe","slack.exe","WhatsApp.exe","Telegram.exe","Signal.exe","Wacom_Tablet.exe","WacomHost.exe","VBoxTray.exe","vmtoolsd.exe","Bluestacks.exe","ldplayer.exe","nox.exe","SGxService.exe","RAVBg64.exe","AvoluteNS.exe","IntelAudioService.exe","WavesSvc64.exe","SmartByteNetworkService.exe","PowerDVD.exe","P2GoExpress.exe","CorelUpdateHelper.exe","MagixNotifier.exe","CreativeCloud.exe","AdobeUpdater.exe","OfficeClickToRun.exe","OfficeBackgroundTaskHandler.exe","Outlook.exe","backgroundTaskHost.exe","FeedbackHub.exe","GameInputRedistributable.exe","FrameServer.exe"
,"Spotify.exe","OneDrive.exe","Steam.exe","EpicGamesLauncher.exe","Discord.exe","WhatsApp.exe","Telegram.exe","Slack.exe","Zoom.exe","Teams.exe","Skype.exe","iTunes.exe","chrome.exe","msedge.exe","firefox.exe","opera.exe","brave.exe","notepad++.exe","vlc.exe","vivaldi.exe","tor.exe","safari.exe","Netflix.exe","PrimeVideo.exe","Tidal.exe","Deezer.exe","YouTubeMusic.exe","Battle.net.exe","Origin.exe","UbisoftConnect.exe","RiotClientServices.exe","GOGGalaxy.exe","RockstarLauncher.exe","Signal.exe","Viber.exe","Messenger.exe","Dropbox.exe","GoogleDriveFS.exe","Box.exe","MegaClient.exe","WPSOffice.exe","LibreOffice.exe","Evernote.exe","Notion.exe","Outlook.exe","SublimeText.exe","Code.exe","atom.exe","vim.exe","emacs.exe","pycharm64.exe","eclipse.exe","webstorm64.exe","mpc-hc64.exe","Winamp.exe","KMPlayer.exe","PotPlayer.exe","QuickTimePlayer.exe","Kodi.exe","AdobeARM.exe","AcroRd32.exe","FoxitReader.exe","TeamViewer.exe","AnyDesk.exe","CCleaner.exe","RevoUninPro.exe","WinRAR.exe","7zFM.exe","Everything.exe","FileZilla.exe","XAMPP.exe","Postman.exe","Fiddler.exe","OBS.exe","Streamlabs.exe","CamtasiaStudio.exe","Audacity.exe","Bandicam.exe","Lightshot.exe","SnagitEditor.exe","ShareX.exe","uTorrent.exe","BitTorrent.exe","qBittorrent.exe","VirtualBox.exe","VMware.exe","Docker Desktop.exe","PowerToys.exe","PowerISO.exe","DaemonTools.exe","PaintDotNet.exe","GIMP.exe","Photoshop.exe","Illustrator.exe","AfterFX.exe","Premiere.exe","Blender.exe","UnityHub.exe","UnrealEditor.exe","Cinema4D.exe","3dsmax.exe","maya.exe","ZBrush.exe","Substance3D.exe","Houdini.exe","Construct3.exe","GameMaker.exe","RPGMaker.exe","VisualBoyAdvance.exe","PCSX2.exe","Yuzu.exe","Citra.exe","RPCS3.exe","Dolphin.exe","RetroArch.exe","CheatEngine.exe","Reshade.exe","MSIAB.exe","RazerSynapse.exe","CorsairUtilityEngine.exe","LogiOverlay.exe","NVIDIASettings.exe","GeForceExperience.exe","AMDSoftware.exe","IntelGraphicsCommandCenter.exe","IntelDriverSupportAssistant.exe","CPUIDCPUZ.exe","HWMonitor.exe","CrystalDiskInfo.exe","CrystalDiskMark.exe","SpeedFan.exe","Rainmeter.exe","WallpaperEngine.exe","Fences.exe","Start11.exe","RocketDock.exe","ObjectDock.exe","Launchy.exe","EverythingToolbar.exe","TeraCopy.exe","FastCopy.exe","FreeDownloadManager.exe","InternetDownloadManager.exe","JDownloader2.exe","Greenshot.exe","IrfanView.exe","XNView.exe","PDFCreator.exe","PDFXChangeEditor.exe","SumatraPDF.exe","NitroPDF.exe","WondersharePDFelement.exe","Calibre.exe","Kindle.exe","TelegramDesktop.exe","WhatsAppDesktop.exe","FacebookMessenger.exe","LINE.exe","ICQ.exe","Trillian.exe","Franz.exe","Rambox.exe","Riot.exe","Element.exe","Mattermost.exe","Zalo.exe","Wechat.exe","DingTalk.exe","ZoomIt.exe","MouseWithoutBorders.exe","Synergy.exe","Barrier.exe","ShareMouse.exe","InputDirector.exe","MultiMonitorTool.exe","DisplayFusion.exe","ActualMultipleMonitors.exe","Clover.exe","QTTabBar.exe","TreeSizeFree.exe","WinDirStat.exe","SpaceSniffer.exe","WizTree.exe","GlaryUtilities.exe","AdvancedSystemCare.exe","WiseCare365.exe","BleachBit.exe","O&OShutUp10.exe","Recuva.exe","PhotoRec.exe","EaseUSDataRecovery.exe","MiniToolPowerDataRecovery.exe","Rufus.exe","Ventoy.exe","Etcher.exe","UNetbootin.exe","YUMI.exe","BalenaEtcher.exe"]

apps_to_install = ["Spotify.exe","OneDrive.exe","Steam.exe","EpicGamesLauncher.exe","Discord.exe","WhatsApp.exe","Telegram.exe","Slack.exe","Zoom.exe","Teams.exe","Skype.exe","iTunes.exe","chrome.exe","msedge.exe","firefox.exe","opera.exe","brave.exe","notepad++.exe","vlc.exe","vivaldi.exe","tor.exe","safari.exe","Netflix.exe","PrimeVideo.exe","Tidal.exe","Deezer.exe","YouTubeMusic.exe","Battle.net.exe","Origin.exe","UbisoftConnect.exe","RiotClientServices.exe","GOGGalaxy.exe","RockstarLauncher.exe","Signal.exe","Viber.exe","Messenger.exe","Dropbox.exe","GoogleDriveFS.exe","Box.exe","MegaClient.exe","WPSOffice.exe","LibreOffice.exe","Evernote.exe","Notion.exe","Outlook.exe","SublimeText.exe","Code.exe","atom.exe","vim.exe","emacs.exe","pycharm64.exe","eclipse.exe","webstorm64.exe","mpc-hc64.exe","Winamp.exe","KMPlayer.exe","PotPlayer.exe","QuickTimePlayer.exe","Kodi.exe","AdobeARM.exe","AcroRd32.exe","FoxitReader.exe","TeamViewer.exe","AnyDesk.exe","CCleaner.exe","RevoUninPro.exe","WinRAR.exe","7zFM.exe","Everything.exe","FileZilla.exe","XAMPP.exe","Postman.exe","Fiddler.exe","OBS.exe","Streamlabs.exe","CamtasiaStudio.exe","Audacity.exe","Bandicam.exe","Lightshot.exe","SnagitEditor.exe","ShareX.exe","uTorrent.exe","BitTorrent.exe","qBittorrent.exe","VirtualBox.exe","VMware.exe","Docker Desktop.exe","PowerToys.exe","PowerISO.exe","DaemonTools.exe","PaintDotNet.exe","GIMP.exe","Photoshop.exe","Illustrator.exe","AfterFX.exe","Premiere.exe","Blender.exe","UnityHub.exe","UnrealEditor.exe","Cinema4D.exe","3dsmax.exe","maya.exe","ZBrush.exe","Substance3D.exe","Houdini.exe","Construct3.exe","GameMaker.exe","RPGMaker.exe","VisualBoyAdvance.exe","PCSX2.exe","Yuzu.exe","Citra.exe","RPCS3.exe","Dolphin.exe","RetroArch.exe","CheatEngine.exe","Reshade.exe","MSIAB.exe","RazerSynapse.exe","CorsairUtilityEngine.exe","LogiOverlay.exe","NVIDIASettings.exe","GeForceExperience.exe","AMDSoftware.exe","IntelGraphicsCommandCenter.exe","IntelDriverSupportAssistant.exe","CPUIDCPUZ.exe","HWMonitor.exe","CrystalDiskInfo.exe","CrystalDiskMark.exe","SpeedFan.exe","Rainmeter.exe","WallpaperEngine.exe","Fences.exe","Start11.exe","RocketDock.exe","ObjectDock.exe","Launchy.exe","EverythingToolbar.exe","TeraCopy.exe","FastCopy.exe","FreeDownloadManager.exe","InternetDownloadManager.exe","JDownloader2.exe","Greenshot.exe","IrfanView.exe","XNView.exe","PDFCreator.exe","PDFXChangeEditor.exe","SumatraPDF.exe","NitroPDF.exe","WondersharePDFelement.exe","Calibre.exe","Kindle.exe","TelegramDesktop.exe","WhatsAppDesktop.exe","FacebookMessenger.exe","LINE.exe","ICQ.exe","Trillian.exe","Franz.exe","Rambox.exe","Riot.exe","Element.exe","Mattermost.exe","Zalo.exe","Wechat.exe","DingTalk.exe","ZoomIt.exe","MouseWithoutBorders.exe","Synergy.exe","Barrier.exe","ShareMouse.exe","InputDirector.exe","MultiMonitorTool.exe","DisplayFusion.exe","ActualMultipleMonitors.exe","Clover.exe","QTTabBar.exe","TreeSizeFree.exe","WinDirStat.exe","SpaceSniffer.exe","WizTree.exe","GlaryUtilities.exe","AdvancedSystemCare.exe","WiseCare365.exe","BleachBit.exe","O&OShutUp10.exe","Recuva.exe","PhotoRec.exe","EaseUSDataRecovery.exe","MiniToolPowerDataRecovery.exe","Rufus.exe","Ventoy.exe","Etcher.exe","UNetbootin.exe","YUMI.exe","BalenaEtcher.exe"]


apps_to_uninstall = apps_to_install

while True:
    display_menu()
    choice = input(f"{white}Choose an option (1-10 or 'exit'): {reset}")

    if choice == "1":
        print(f"{red}[INFO]{reset} Launching Task Cleaner...")
        for task in task_list:
            kill_task(task)
        os.system("start explorer.exe")

    elif choice == "2":
        print(f"{red}[INFO]{reset} Launching App Uninstaller...")
        for idx, app in enumerate(apps_to_uninstall, 1):
            print(f"{red}[{white}{idx}{red}]{white} {app}")
        app_choice = input(f"\n{white}Enter the number of the app to uninstall: {reset}")
        if app_choice.isdigit() and 1 <= int(app_choice) <= len(apps_to_uninstall):
            uninstall_app(apps_to_uninstall[int(app_choice) - 1])
        else:
            print(f"{red}[ERROR]{reset} Invalid choice.")

    elif choice == "3":
        print(f"{red}[INFO]{reset} Launching App Installer...")
        for idx, app in enumerate(apps_to_install, 1):
            print(f"{red}[{white}{idx}{red}]{white} {app}")
        app_choice = input(f"\n{white}Enter the number of the app to install: {reset}")
        if app_choice.isdigit() and 1 <= int(app_choice) <= len(apps_to_install):
            install_app(apps_to_install[int(app_choice) - 1])
        else:
            print(f"{red}[ERROR]{reset} Invalid choice.")

    elif choice == "4":
        clean_temp_files()

    elif choice == "5":
        refresh_ip()

    elif choice == "6":
        while True:
            print(f"{red}[INFO]{reset} Launching Antivirus Scanner...\n")
            print(f"{red}[1]{white} Quick Scan")
            print(f"{red}[2]{white} Full Scan")
            print(f"{red}[3]{white} Return to Main Menu")
            scan_option = input(f"{white}Choose an option (1-3): {reset}")
        
            if scan_option == "1":
                antivirus_scan_q()
            elif scan_option == "2":
                antivirus_scan_f()
            elif scan_option == "3":
                break
            else:
                print(f"{red}[ERROR]{reset} Invalid scan option.")

    elif choice == "11":
        ip_lookup()

    elif choice in ["7", "8", "9", "10"]:
        print(f"{red}[INFO]{reset} This feature is coming soon.")

    elif choice.lower() == "exit":
        print(f"{red}[EXIT]{reset} Exiting the menu.")
        break

    else:
        print(f"{red}[ERROR]{reset} Invalid option.")

    input(f"\n{white}Press Enter to return to the menu...{reset}")
    os.system("cls")

import requests
from Config.Util import *
from Config.Config import *

def ip_lookup():
    Title("Ip Lookup")
    
    try:
        Slow(map_banner)
        ip = input(f"\n{BEFORE + current_time_hour() + AFTER} {INPUT} Ip -> {reset}")
        print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Search for information..")

        try:
            response = requests.get(f"https://{website}/api/ip/ip={ip}")
            api = response.json()

            ip = api.get('ip')
            status = api.get('status')
            country = api.get('country')
            country_code = api.get('country_code')
            region = api.get('region')
            region_code = api.get('region_code')
            zip = api.get('zip')
            city = api.get('city')
            latitude = api.get('latitude')
            longitude = api.get('longitude')
            timezone = api.get('timezone')
            isp = api.get('isp')
            org = api.get('org')
            as_host = api.get('as')

        except:
            response = requests.get(f"http://ip-api.com/json/{ip}")
            api = response.json()

            status = "Valid" if api.get('status') == "success" else "Invalid"
            country = api.get('country', "None")
            country_code = api.get('countryCode', "None")
            region = api.get('regionName', "None")
            region_code = api.get('region', "None")
            zip = api.get('zip', "None")
            city = api.get('city', "None")
            latitude = api.get('lat', "None")
            longitude = api.get('lon', "None")
            timezone = api.get('timezone', "None")
            isp = api.get('isp', "None")
            org = api.get('org', "None")
            as_host = api.get('as', "None")

        Slow(f"""    
        {INFO_ADD} Status    : {white}{status}{red}
        {INFO_ADD} Country   : {white}{country} ({country_code}){red}
        {INFO_ADD} Region    : {white}{region} ({region_code}){red}
        {INFO_ADD} Zip       : {white}{zip}{red}
        {INFO_ADD} City      : {white}{city}{red}
        {INFO_ADD} Latitude  : {white}{latitude}{red}
        {INFO_ADD} Longitude : {white}{longitude}{red}
        {INFO_ADD} Timezone  : {white}{timezone}{red}
        {INFO_ADD} Isp       : {white}{isp}{red}
        {INFO_ADD} Org       : {white}{org}{red}
        {INFO_ADD} As        : {white}{as_host}{red}{reset}
        """)

        Continue()
        Reset()

    except Exception as e:
        Error(e)