#######################################
#                                     #
#   by The_ggpro  -  Copyright 2025   #
#                                     #
#######################################




red = "\033[91m"
white = "\033[97m"
reset = "\033[0m"

try:
    import webbrowser
    import re
    import pyzipper
    from tkinter import messagebox
    import subprocess
    import os
    import time
except Exception as e:
    print(f"Module Error: {e}")

def resize_console():
    if os.name == "nt":
        os.system("mode con: cols=85 lines=30")

resize_console()

option_01 = "Task Cleaner"
option_02 = "App Uninstaller"
option_03 = "App Installer"
option_04 = "Temp File Cleaner"
option_05 = "IP Refresh"
option_06 = "Antivirus Scan"
option_07 = "Soon"
option_08 = "Soon"
option_09 = "Soon"
option_10 = "Soon"

logo_ascii = r"""
           ___      ___ ________  ___       ___  ________          ___    ___ 
          |\  \    /  /|\   __  \|\  \     |\  \|\   ___  \       |\  \  /  /|
          \ \  \  /  / | \  \|\  \ \  \    \ \  \ \  \\ \  \      \ \  \/  / /
           \ \  \/  / / \ \   __  \ \  \    \ \  \ \  \\ \  \      \ \    / / 
            \ \    / /   \ \  \ \  \ \  \____\ \  \ \  \\ \  \ ___  /     \/  
             \ \__/ /     \ \__\ \__\ \_______\ \__\ \__\\ \__\\__ /  /\   \  
              \|__|/       \|__|\|__|\|_______|\|__|\|__| \|__\|__/__/ /\ __\ 
                                                                  |__|/ \|__|   
"""

option_info_txt = "V1.0"
option_next_txt = "Next Soon"
option_site_txt = "Any Site For The Moment."

def format_option(index, text):
    return f"{red}[{white}{index:02d}{red}]{white} {text.ljust(30)[:30].replace('-', ' ')}{reset}"

options_txt = [format_option(i + 1, text) for i, text in enumerate([
    option_01, option_02, option_03, option_04, option_05,
    option_06, option_07, option_08, option_09, option_10
])]

def display_menu():
    print(f"""
{logo_ascii}
 ┌─ {option_info_txt:<100}
 ├─ {option_site_txt:<114}
 └─┬──────────────────────────────────────────────────────────────────────────────────────┐
   │ Local Device                                                                         │
   └──────────────────────────────────────────────────────────────────────────────────────┘
   {options_txt[0]}
   {options_txt[1]}
   {options_txt[2]}
   {options_txt[3]}
   {options_txt[4]}
   {options_txt[5]}
   {options_txt[6]}
   {options_txt[7]}
   {options_txt[8]}
   {options_txt[9]}
 ──────────────────────────────────────────────────────────────────────────────────────────
""")

def loading_bar(task_name):
    print(f"{red}[INFO]{reset} Processing {task_name}:", end=" ")
    for i in range(20):
        print("█", end="", flush=True)
        time.sleep(0.05)
    print(f" {red}[DONE]{reset}")

def kill_task(task_name):
    try:
        subprocess.run(['taskkill', '/f', '/im', task_name], capture_output=True, text=True)
        print(f"{red}[KILL]{reset} {task_name} has been terminated.")
    except Exception as e:
        print(f"{red}[ERROR]{reset} Could not terminate {task_name}: {e}")

def uninstall_app(app_name):
    try:
        print(f"{red}[INFO]{reset} Uninstalling: {app_name}")
        command = f'powershell "Get-WmiObject -Query \\"SELECT * FROM Win32_Product WHERE Name = \'{app_name}\'\\" | ForEach-Object {{$_.Uninstall()}}"'
        loading_bar(app_name)
        subprocess.run(command, shell=True)
        print(f"{red}[FINISH]{reset} {app_name} has been uninstalled.")
    except Exception as e:
        print(f"{red}[ERROR]{reset} Could not uninstall {app_name}: {e}")

def install_app(app_name):
    try:
        print(f"{red}[INFO]{reset} Installing: {app_name}")
        loading_bar(app_name)
        os.system(f"winget install --silent --accept-source-agreements --accept-package-agreements \"{app_name}\"")
        print(f"{red}[FINISH]{reset} {app_name} has been installed.")
    except Exception as e:
        print(f"{red}[ERROR]{reset} Could not install {app_name}: {e}")

def clean_temp_files():
    try:
        print(f"{red}[INFO]{reset} Cleaning temporary files...")
        loading_bar("Temp Cleaner")
        os.system("del /q/f/s %TEMP%\\*")
        os.system("del /s /f /q C:\\Windows\\Temp\\*")
        print(f"{red}[FINISH]{reset} Temporary files cleaned.")
    except Exception as e:
        print(f"{red}[ERROR]{reset} Failed to clean temp files: {e}")

def refresh_ip():
    try:
        print(f"{red}[INFO]{reset} Refreshing IP address...")
        loading_bar("IP Refresh")
        os.system("ipconfig /release")
        os.system("ipconfig /renew")
        print(f"{red}[FINISH]{reset} IP address refreshed.")
    except Exception as e:
        print(f"{red}[ERROR]{reset} Failed to refresh IP: {e}")

def antivirus_scan():
    try:
        print(f"{red}[INFO]{reset} Starting antivirus scan...")
        loading_bar("Virus Scan")
        os.system("powershell Start-MpScan -ScanType QuickScan")
        print(f"{red}[FINISH]{reset} Scan complete.")
    except Exception as e:
        print(f"{red}[ERROR]{reset} Antivirus scan failed: {e}")

task_list = ["explorer.exe","Spotify.exe","OneDrive.exe","Steam.exe","EpicGamesLauncher.exe","Discord.exe","WhatsApp.exe","Telegram.exe","Slack.exe","Zoom.exe","Teams.exe","Skype.exe","iTunes.exe","chrome.exe","msedge.exe","firefox.exe","opera.exe","brave.exe","notepad++.exe","vlc.exe","vivaldi.exe","tor.exe","safari.exe","Netflix.exe","PrimeVideo.exe","Tidal.exe","Deezer.exe","YouTubeMusic.exe","Battle.net.exe","Origin.exe","UbisoftConnect.exe","RiotClientServices.exe","GOGGalaxy.exe","RockstarLauncher.exe","Signal.exe","Viber.exe","Messenger.exe","Dropbox.exe","GoogleDriveFS.exe","Box.exe","MegaClient.exe","WPSOffice.exe","LibreOffice.exe","Evernote.exe","Notion.exe","Outlook.exe","SublimeText.exe","Code.exe","atom.exe","vim.exe","emacs.exe","pycharm64.exe","eclipse.exe","webstorm64.exe","mpc-hc64.exe","Winamp.exe","KMPlayer.exe","PotPlayer.exe","QuickTimePlayer.exe","Kodi.exe","AdobeARM.exe","AcroRd32.exe","FoxitReader.exe","TeamViewer.exe","AnyDesk.exe","CCleaner.exe","RevoUninPro.exe","WinRAR.exe","7zFM.exe","Everything.exe","FileZilla.exe","XAMPP.exe","Postman.exe","Fiddler.exe","OBS.exe","Streamlabs.exe","CamtasiaStudio.exe","Audacity.exe","Bandicam.exe","Lightshot.exe","SnagitEditor.exe","ShareX.exe","uTorrent.exe","BitTorrent.exe","qBittorrent.exe","VirtualBox.exe","VMware.exe","Docker Desktop.exe","PowerToys.exe","PowerISO.exe","DaemonTools.exe","PaintDotNet.exe","GIMP.exe","Photoshop.exe","Illustrator.exe","AfterFX.exe","Premiere.exe","Blender.exe","UnityHub.exe","UnrealEditor.exe","Cinema4D.exe","3dsmax.exe","maya.exe","ZBrush.exe","Substance3D.exe","Houdini.exe","Construct3.exe","GameMaker.exe","RPGMaker.exe","VisualBoyAdvance.exe","PCSX2.exe","Yuzu.exe","Citra.exe","RPCS3.exe","Dolphin.exe","RetroArch.exe","CheatEngine.exe","Reshade.exe","MSIAB.exe","RazerSynapse.exe","CorsairUtilityEngine.exe","LogiOverlay.exe","NVIDIASettings.exe","GeForceExperience.exe","AMDSoftware.exe","IntelGraphicsCommandCenter.exe","IntelDriverSupportAssistant.exe","CPUIDCPUZ.exe","HWMonitor.exe","CrystalDiskInfo.exe","CrystalDiskMark.exe","SpeedFan.exe","Rainmeter.exe","WallpaperEngine.exe","Fences.exe","Start11.exe","RocketDock.exe","ObjectDock.exe","Launchy.exe","EverythingToolbar.exe","TeraCopy.exe","FastCopy.exe","FreeDownloadManager.exe","InternetDownloadManager.exe","JDownloader2.exe","Greenshot.exe","IrfanView.exe","XNView.exe","PDFCreator.exe","PDFXChangeEditor.exe","SumatraPDF.exe","NitroPDF.exe","WondersharePDFelement.exe","Calibre.exe","Kindle.exe","TelegramDesktop.exe","WhatsAppDesktop.exe","FacebookMessenger.exe","LINE.exe","ICQ.exe","Trillian.exe","Franz.exe","Rambox.exe","Riot.exe","Element.exe","Mattermost.exe","Zalo.exe","Wechat.exe","DingTalk.exe","ZoomIt.exe","MouseWithoutBorders.exe","Synergy.exe","Barrier.exe","ShareMouse.exe","InputDirector.exe","MultiMonitorTool.exe","DisplayFusion.exe","ActualMultipleMonitors.exe","Clover.exe","QTTabBar.exe","TreeSizeFree.exe","WinDirStat.exe","SpaceSniffer.exe","WizTree.exe","GlaryUtilities.exe","AdvancedSystemCare.exe","WiseCare365.exe","BleachBit.exe","O&OShutUp10.exe","Recuva.exe","PhotoRec.exe","EaseUSDataRecovery.exe","MiniToolPowerDataRecovery.exe","Rufus.exe","Ventoy.exe","Etcher.exe","UNetbootin.exe","YUMI.exe","BalenaEtcher.exe"]

apps_to_install = ["Spotify.exe","OneDrive.exe","Steam.exe","EpicGamesLauncher.exe","Discord.exe","WhatsApp.exe","Telegram.exe","Slack.exe","Zoom.exe","Teams.exe","Skype.exe","iTunes.exe","chrome.exe","msedge.exe","firefox.exe","opera.exe","brave.exe","notepad++.exe","vlc.exe","vivaldi.exe","tor.exe","safari.exe","Netflix.exe","PrimeVideo.exe","Tidal.exe","Deezer.exe","YouTubeMusic.exe","Battle.net.exe","Origin.exe","UbisoftConnect.exe","RiotClientServices.exe","GOGGalaxy.exe","RockstarLauncher.exe","Signal.exe","Viber.exe","Messenger.exe","Dropbox.exe","GoogleDriveFS.exe","Box.exe","MegaClient.exe","WPSOffice.exe","LibreOffice.exe","Evernote.exe","Notion.exe","Outlook.exe","SublimeText.exe","Code.exe","atom.exe","vim.exe","emacs.exe","pycharm64.exe","eclipse.exe","webstorm64.exe","mpc-hc64.exe","Winamp.exe","KMPlayer.exe","PotPlayer.exe","QuickTimePlayer.exe","Kodi.exe","AdobeARM.exe","AcroRd32.exe","FoxitReader.exe","TeamViewer.exe","AnyDesk.exe","CCleaner.exe","RevoUninPro.exe","WinRAR.exe","7zFM.exe","Everything.exe","FileZilla.exe","XAMPP.exe","Postman.exe","Fiddler.exe","OBS.exe","Streamlabs.exe","CamtasiaStudio.exe","Audacity.exe","Bandicam.exe","Lightshot.exe","SnagitEditor.exe","ShareX.exe","uTorrent.exe","BitTorrent.exe","qBittorrent.exe","VirtualBox.exe","VMware.exe","Docker Desktop.exe","PowerToys.exe","PowerISO.exe","DaemonTools.exe","PaintDotNet.exe","GIMP.exe","Photoshop.exe","Illustrator.exe","AfterFX.exe","Premiere.exe","Blender.exe","UnityHub.exe","UnrealEditor.exe","Cinema4D.exe","3dsmax.exe","maya.exe","ZBrush.exe","Substance3D.exe","Houdini.exe","Construct3.exe","GameMaker.exe","RPGMaker.exe","VisualBoyAdvance.exe","PCSX2.exe","Yuzu.exe","Citra.exe","RPCS3.exe","Dolphin.exe","RetroArch.exe","CheatEngine.exe","Reshade.exe","MSIAB.exe","RazerSynapse.exe","CorsairUtilityEngine.exe","LogiOverlay.exe","NVIDIASettings.exe","GeForceExperience.exe","AMDSoftware.exe","IntelGraphicsCommandCenter.exe","IntelDriverSupportAssistant.exe","CPUIDCPUZ.exe","HWMonitor.exe","CrystalDiskInfo.exe","CrystalDiskMark.exe","SpeedFan.exe","Rainmeter.exe","WallpaperEngine.exe","Fences.exe","Start11.exe","RocketDock.exe","ObjectDock.exe","Launchy.exe","EverythingToolbar.exe","TeraCopy.exe","FastCopy.exe","FreeDownloadManager.exe","InternetDownloadManager.exe","JDownloader2.exe","Greenshot.exe","IrfanView.exe","XNView.exe","PDFCreator.exe","PDFXChangeEditor.exe","SumatraPDF.exe","NitroPDF.exe","WondersharePDFelement.exe","Calibre.exe","Kindle.exe","TelegramDesktop.exe","WhatsAppDesktop.exe","FacebookMessenger.exe","LINE.exe","ICQ.exe","Trillian.exe","Franz.exe","Rambox.exe","Riot.exe","Element.exe","Mattermost.exe","Zalo.exe","Wechat.exe","DingTalk.exe","ZoomIt.exe","MouseWithoutBorders.exe","Synergy.exe","Barrier.exe","ShareMouse.exe","InputDirector.exe","MultiMonitorTool.exe","DisplayFusion.exe","ActualMultipleMonitors.exe","Clover.exe","QTTabBar.exe","TreeSizeFree.exe","WinDirStat.exe","SpaceSniffer.exe","WizTree.exe","GlaryUtilities.exe","AdvancedSystemCare.exe","WiseCare365.exe","BleachBit.exe","O&OShutUp10.exe","Recuva.exe","PhotoRec.exe","EaseUSDataRecovery.exe","MiniToolPowerDataRecovery.exe","Rufus.exe","Ventoy.exe","Etcher.exe","UNetbootin.exe","YUMI.exe","BalenaEtcher.exe"]


apps_to_uninstall = task_list

while True:
    display_menu()
    choice = input(f"{white}Choose an option (1-10 or 'exit'): {reset}")

    if choice == "1":
        print(f"{red}[INFO]{reset} Launching Task Cleaner...")
        for task in task_list:
            kill_task(task)
        os.system("start explorer.exe")

    elif choice == "2":
        print(f"{red}[INFO]{reset} Launching App Uninstaller...")
        for idx, app in enumerate(apps_to_uninstall, 1):
            print(f"{red}[{white}{idx}{red}]{white} {app}")
        app_choice = input(f"\n{white}Enter the number of the app to uninstall: {reset}")
        if app_choice.isdigit() and 1 <= int(app_choice) <= len(apps_to_uninstall):
            uninstall_app(apps_to_uninstall[int(app_choice) - 1])
        else:
            print(f"{red}[ERROR]{reset} Invalid choice.")

    elif choice == "3":
        print(f"{red}[INFO]{reset} Launching App Installer...")
        for idx, app in enumerate(apps_to_install, 1):
            print(f"{red}[{white}{idx}{red}]{white} {app}")
        app_choice = input(f"\n{white}Enter the number of the app to install: {reset}")
        if app_choice.isdigit() and 1 <= int(app_choice) <= len(apps_to_install):
            install_app(apps_to_install[int(app_choice) - 1])
        else:
            print(f"{red}[ERROR]{reset} Invalid choice.")

    elif choice == "4":
        clean_temp_files()

    elif choice == "5":
        refresh_ip()

    elif choice == "6":
        antivirus_scan()

    elif choice in ["7", "8", "9", "10"]:
        print(f"{red}[INFO]{reset} This feature is coming soon.")

    elif choice.lower() == "exit":
        print(f"{red}[EXIT]{reset} Exiting the menu.")
        break

    else:
        print(f"{red}[ERROR]{reset} Invalid option.")

    input(f"\n{white}Press Enter to return to the menu...{reset}")
